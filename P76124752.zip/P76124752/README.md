# Clustering
> python my_clustering.py


> github:https://github.com/shangyuan191/Clustering
## Experiments
> Using DB-SCAN algorithm,and perform grid search method to find the better (eps,minPts).
![alt text](image.png)
* ### Clusrering_test1
    * #### eps:8
    * #### minPts:39
    * #### num of cluster:4 (without noise)
    * #### plot:
![alt text](Figure_1.png)

----------------------------------------------------

* ### Clusrering_test2
    * #### eps:8
    * #### minPts:33
    * #### num of cluster:4 (without noise)
    * #### plot:
![alt text](Figure_2.png)

----------------------------------------------------


* ### Clusrering_test3
    * #### eps:7
    * #### minPts:31
    * #### num of cluster:4 (without noise)
    * #### plot:
![alt text](Figure_3.png)


----------------------------------------------------


* ### Clusrering_test4
    * #### eps:5
    * #### minPts:39
    * #### num of cluster:3 (without noise)
    * #### plot:
![alt text](Figure_4.png)


----------------------------------------------------


* ### Clusrering_test5
    * #### eps:6
    * #### minPts:37
    * #### num of cluster:3 (without noise)
    * #### plot:
![alt text](Figure_5.png)
